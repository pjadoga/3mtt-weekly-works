<?php
$servername = "sql208.infinityfree.com";//localhost
$username = "if0_37574872";//root
$password = "080PJadoga";//empty
$dbname = "if0_37574872_conflictapp";//conflict_resolution

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>