<nav class="w-64 bg-gradient-to-b from-green-500 shadow-md h-screen">
      <div class="p-6">
        <a href="#" class="text-slate-500 hover:text-blue-75 text-lg font-semibold block">Dashboard</a>
        <a href="#" class="text-slate-500 hover:text-blue-75 text-lg font-semibold block mt-4">Submit a case</a>
        <a href="#" class="text-slate-500 hover:text-blue-75 text-lg font-semibold block mt-4">View Reports</a>
        <a href="#" class="text-slate-500 hover:text-blue-75 text-lg font-semibold block mt-4">Settings</a>
      </div>
</nav>